package it.uniroma3.diadia.personaggi;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class Cane extends AbstractPersonaggio{

	private static final String MESSAGGIO_MORSO = "Sei stato morso... Hai perso 1 CFU!";
	private static final String ACCETTATO = "REGALO ACCETTATO";
	private static final String NONACCETTATO = "REGALO NON ACCETTATO";

	private Attrezzo attrezzoTenuto;
	private String ciboPreferito;
	
	
	public Cane(String nome, String presentaz, String attrezzo, int peso, String ciboPreferito) {
		super(nome, presentaz);
		this.attrezzoTenuto = new Attrezzo(attrezzo, peso);
		this.ciboPreferito = ciboPreferito;
	}
	
	public void setAttrezzo(Attrezzo attrezzo) {
		this.attrezzoTenuto = attrezzo;
	}

	@Override
	public String agisci(Partita partita) {
		String msg;
		partita.getGiocatore().setCfu( partita.getGiocatore().getCfu()-1 );
		msg = MESSAGGIO_MORSO;
		return msg;
	}

	@Override
	public String riceviRegalo(Attrezzo attrezzoRegalato, Partita partita) {
		
		if( attrezzoRegalato.getNome().equals(ciboPreferito) ) {
			partita.getStanzaCorrente().addAttrezzo(attrezzoTenuto);
			this.setAttrezzo(attrezzoRegalato);
			this.setRegaloAccettato(true);
			return ACCETTATO;
		}
		else 
			return (this.agisci(partita) + NONACCETTATO)  ;
		
	}
	
	

}
