package it.uniroma3.diadia.personaggi;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public abstract class AbstractPersonaggio {

	private String nome;
	private String presentazione;
	private boolean haSalutato;
	private boolean regaloAccettato;

	public AbstractPersonaggio(String nome, String presentaz) {
		this.nome = nome;
		this.presentazione = presentaz;
		this.haSalutato = false;
	}

	public String getNome() {
		return this.nome;
	}

	public boolean getHaSalutato() {
		return this.haSalutato;
	}
	
	public void setHaSalutato() {
		haSalutato = true;
	}
	
	public String saluta() {
		
		StringBuilder risposta =

				new StringBuilder("Ciao, io sono ");

		risposta.append(this.getNome()+".");
		if (!haSalutato)

			risposta.append(this.presentazione);

		else

			risposta.append(" Ci siamo gia' presentati!");

		this.setHaSalutato();
		return risposta.toString();
	}

	abstract public String agisci(Partita partita);

	@Override
	public String toString() {
		return this.getNome();
	}
	
	public abstract String riceviRegalo(Attrezzo attrezzo, Partita partita) ;

	public boolean getRegaloAccettato() {
		return regaloAccettato;
	}

	public void setRegaloAccettato(boolean regaloAccettato) {
		this.regaloAccettato = regaloAccettato;
	}

}
