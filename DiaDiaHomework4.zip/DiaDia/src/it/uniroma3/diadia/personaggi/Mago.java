package it.uniroma3.diadia.personaggi;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class Mago extends AbstractPersonaggio {
	
	private static final String MESSAGGIO_DONO = "Sei un vero simpaticone, " +
			"con una mia magica azione, troverai un nuovo oggetto " +
			"per il tuo borsone!";
	private static final String MESSAGGIO_SCUSE = "Mi spiace, ma non ho piu' nulla...";
	private static final String DIMEZZO = "Adesso il tuo attrezzo e' pi� leggero";
	private Attrezzo attrezzo;
	private Attrezzo regalo;
	
	public Mago(String nome, String presentazione, Attrezzo attrezzo) {
		super(nome, presentazione);
		this.attrezzo = attrezzo;
		this.setRegaloAccettato(true);
		
	}
	
	@Override
	public String agisci(Partita partita) {
		String msg;
		if (this.attrezzo!=null) {
			partita.getStanzaCorrente().addAttrezzo(this.attrezzo);
			this.attrezzo = null;
			msg = MESSAGGIO_DONO;
		}
		else {
			msg = MESSAGGIO_SCUSE;
		}
		return msg;
	}

	@Override
	public String riceviRegalo(Attrezzo attrezzoRegalato, Partita partita) {
		
		String nomeAttrezzoRegalato = attrezzoRegalato.getNome();
		int pesoAttrezzoRegalato = attrezzoRegalato.getPeso();
		
		this.regalo = new Attrezzo( nomeAttrezzoRegalato, pesoAttrezzoRegalato/2);
		partita.getStanzaCorrente().addAttrezzo( this.getRegalo() );
		
		return DIMEZZO;
		
	}

	public Attrezzo getRegalo() {
		return regalo;
	}

	public void setRegalo(Attrezzo regalo) {
		this.regalo = regalo;
	}
}