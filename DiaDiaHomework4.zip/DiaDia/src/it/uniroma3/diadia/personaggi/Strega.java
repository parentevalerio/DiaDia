package it.uniroma3.diadia.personaggi;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Direzione;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class Strega extends AbstractPersonaggio{

	private static final String STRINGA_TELEPORT = "Sei stato teletrasportato!";
	private static final String RISATA = "AHAHAHHAHAHAHAHHAHAHAH!";
	private Map<Direzione, Stanza> direzione2stanzeAdiacenti;
	private Attrezzo regalo; 

	

	public Strega(String nome, String presentaz) {
		super(nome, presentaz);
		this.setRegaloAccettato(true);
	}


	
	@Override
	public String agisci(Partita partita) {

		direzione2stanzeAdiacenti = partita.getStanzaCorrente().getDirezione2StanzeAdiacenti();
		List<Direzione> direzioni = new LinkedList<>();
		direzioni.addAll(direzione2stanzeAdiacenti.keySet());
		int dim = direzioni.size();
		String msg = STRINGA_TELEPORT;
		
	
		if (this.getHaSalutato() == true) {
			int max = 0 ;
			int index = 0;
			for ( int i=0; i < dim; i++ ) {
				if( max < direzione2stanzeAdiacenti.get(direzioni.get(i)).getNumeroAttrezzi()) {
					max = direzione2stanzeAdiacenti.get(direzioni.get(i)).getNumeroAttrezzi();
					index = i;
				}
				partita.setStanzaCorrente(direzione2stanzeAdiacenti.get(direzioni.get(index)));
			}
		}
		else {
			int min = direzione2stanzeAdiacenti.get(direzioni.get(0)).getNumeroAttrezzi() ;
			int index = 0;
			for ( int i=0; i < dim; i++ ) {
				if( min > direzione2stanzeAdiacenti.get(direzioni.get(i)).getNumeroAttrezzi()) {
					min = direzione2stanzeAdiacenti.get(direzioni.get(i)).getNumeroAttrezzi();
					index = i;
				}
				partita.setStanzaCorrente(direzione2stanzeAdiacenti.get(direzioni.get(index)));

			}
		}
		return msg;
	}



	@Override
	public String riceviRegalo(Attrezzo attrezzoRegalato, Partita partita) {
		this.setRegalo(attrezzoRegalato);
		return RISATA;
	}

	public Attrezzo getRegalo() {
		return regalo;
	}

	public void setRegalo(Attrezzo regalo) {
		this.regalo = regalo;
	}

}




