package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;

public class ComandoBorsa extends AbstractComando{


	

	@Override
	public void esegui(Partita partita) {
		this.getIO().mostraMessaggio(partita.getGiocatore().getBorsa().toString()); 
	}

//	@Override
//	public void setParametro(String parametro) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void setIO (IO ioConsole) {
//		this.ioConsole = ioConsole;		
//	}
//
//	@Override
//	public String getNome() {
//		// TODO Auto-generated method stub
//		return "borsa";
//	}
//
//	@Override
//	public void getParametro() {
//		// TODO Auto-generated method stub
//		
//	}


}
