package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;

public class ComandoOrdinato extends AbstractComando{


	String tipoOrdinamento;
	static final String ORDINAMENTOUNO = "nome";
	static final String ORDINAMENTODUE = "peso";
	static final String ORDINAMENTOTRE = "raggruppato";


	@Override
	public void esegui(Partita partita) {
		this.tipoOrdinamento = this.getParametro();
		if (tipoOrdinamento == null)
			this.getIO().mostraMessaggio("Specificare il tipo di ordinamento");

		else {
			if ( partita.getGiocatore().getBorsa().isEmpty() ) { 
				this.getIO().mostraMessaggio("Borsa vuota");
				return;	}
			else {
				if (tipoOrdinamento.equals(ORDINAMENTOUNO)) {
					this.getIO().mostraMessaggio("Contenuto ordinato per nome" + partita.getGiocatore().getBorsa().getContenutoOrdinatoPerNome().toString());
					return;	}
				if (tipoOrdinamento.equals(ORDINAMENTODUE)) {
					this.getIO().mostraMessaggio("Contenuto ordinato per peso" + partita.getGiocatore().getBorsa().getContenutoOrdinatoPerPeso().toString());
					return;	}
				if (tipoOrdinamento.equals(ORDINAMENTOTRE)) {
					this.getIO().mostraMessaggio("Contenuto raggruppato per peso" + partita.getGiocatore().getBorsa().getContenutoRaggruppatoPerPeso().toString());
					return;	}
				}
					this.getIO().mostraMessaggio("Tipo di ordinamento inesistente.");
		}
	}

//	@Override
//	public void setParametro(String parametro) {
//		this.tipoOrdinamento = parametro;
//
//	}
//
//	@Override
//	public void setIO(IO ioConsole) {
//		this.ioConsole = ioConsole;		
//	}
//
//	@Override
//	public String getNome() {
//		return "ordinato";
//	}
//
//	@Override
//	public void getParametro() {
//		// TODO Auto-generated method stub
//
//	}

}
