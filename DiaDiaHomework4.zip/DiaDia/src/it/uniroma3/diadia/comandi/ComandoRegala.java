package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class ComandoRegala extends AbstractComando{

	private String attrezzo;
	private Attrezzo attrezzoRegalo;

	@Override
	public void esegui(Partita partita) {
		if (partita.getStanzaCorrente().getPersonaggio() == null) {
			this.getIO().mostraMessaggio("Nessuno a cui regalare il tuo attrezzo");
			return;
		}
		this.attrezzo = this.getParametro();

		if (attrezzo == null) {
			this.getIO().mostraMessaggio("Specificare l'attrezzo da regalare");
			return;
		}

		else {
			if (partita.getGiocatore().getBorsa().hasAttrezzo(attrezzo) == false) {
				this.getIO().mostraMessaggio("Attrezzo non presente nella borsa");
				return;
			}

			attrezzoRegalo = partita.getGiocatore().getBorsa().getAttrezzo(attrezzo);
			this.getIO().mostraMessaggio( partita.getStanzaCorrente().getPersonaggio().riceviRegalo(attrezzoRegalo, partita) );
			
			if ( partita.getStanzaCorrente().getPersonaggio().getRegaloAccettato() == true) {
			
				partita.getGiocatore().getBorsa().removeAttrezzo(attrezzo);
				this.getIO().mostraMessaggio("Hai regalato " + attrezzo);
			}

			else
				this.getIO().mostraMessaggio("Regalo non accettato");


		}

	}
}



