package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;

public class ComandoFine extends AbstractComando {

	public static String MESSAGGIO_FINE = "Grazie per aver giocato!";
	
	
	@Override
	public void esegui(Partita partita) {
		this.getIO().mostraMessaggio(MESSAGGIO_FINE);
		partita.setFinita();
	}

//	@Override
//	public void setParametro(String parametro) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void setIO(IO ioConsole) {
//		this.ioConsole = ioConsole;		
//	}
//
//	@Override
//	public String getNome() {
//		// TODO Auto-generated method stub
//		return "fine";
//	}
//
//	@Override
//	public void getParametro() {
//		// TODO Auto-generated method stub
//		
//	}

}
