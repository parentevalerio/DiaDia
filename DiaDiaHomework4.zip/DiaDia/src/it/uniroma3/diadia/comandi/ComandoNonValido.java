package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;

public class ComandoNonValido extends AbstractComando {


	@Override
	public void esegui(Partita partita) {
		this.getIO().mostraMessaggio("Comando non valido");
	}

//	@Override
//	public void setParametro(String parametro) {
//		// TODO Auto-generated method stub
//
//	}
//
//	@Override
//	public void setIO(IO ioConsole) {
//		this.ioConsole = ioConsole;
//	}
//
//	@Override
//	public String getNome() {
//		// TODO Auto-generated method stub
//		return "nv";
//	}
//
//	@Override
//	public void getParametro() {
//		// TODO Auto-generated method stub
//		
//	}

}
