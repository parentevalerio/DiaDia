package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class ComandoPosa extends AbstractComando{



	private String attrezzo;
	
	@Override
	public void esegui(Partita partita) {
		this.attrezzo = this.getParametro();
		Stanza stanzaCorrente = partita.getStanzaCorrente();
		if (!partita.getGiocatore().getBorsa().hasAttrezzo(attrezzo)) {
			this.getIO().mostraMessaggio("L'attrezzo che si vuole posare non � nella borsa. ");
			return ;
		}
		if (stanzaCorrente.getNumeroAttrezzi() == 10 ) {
			this.getIO().mostraMessaggio("La stanza � piena.");
			return;
		}
		//sicuramente non null (per i check precedenti)
		Attrezzo attrezzoTrovato = partita.getGiocatore().getBorsa().getAttrezzo(attrezzo);
		stanzaCorrente.addAttrezzo(attrezzoTrovato);
		partita.getGiocatore().removeAttrezzo(attrezzoTrovato);
		this.getIO().mostraMessaggio("Posato " + attrezzoTrovato.getNome() + " in " + stanzaCorrente.getNome()+ ".");
		
	}


}
