package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;

public class ComandoGuarda extends AbstractComando{


	@Override
	public void esegui(Partita partita) {
		Stanza stanzaCorrente = partita.getStanzaCorrente();
		this.getIO().mostraMessaggio("Dai un'occhiata alla stanza " + stanzaCorrente.getDescrizione() + ".");
		this.getIO().mostraMessaggio("CFU attuali: " + partita.getGiocatore().getCfu() + "." );
	}

}
