package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class ComandoPrendi extends AbstractComando{



	private String attrezzo;

	@Override
	public void esegui(Partita partita) {
		this.attrezzo = this.getParametro();
		Stanza stanzaCorrente = partita.getStanzaCorrente();
		Attrezzo attrezzoTrovato = partita.getStanzaCorrente().getAttrezzo(this.attrezzo);
		

		if (attrezzoTrovato == null) {
			this.getIO().mostraMessaggio("Questo elemento non � presente nella stanza");
			return;
		}
		
		if (partita.getGiocatore().getBorsa().getPeso() + attrezzoTrovato.getPeso() > partita.getGiocatore().getBorsa().getPesoMax()) {
			this.getIO().mostraMessaggio("Si sta trasportando troppo peso per prendere questo attrezzo.");
			return ;
		}
		
		if (partita.getGiocatore().getBorsa().getAttrezzi().size() ==10) {
			this.getIO().mostraMessaggio("La borsa ha troppi oggetti.");
			return ;
		}

		stanzaCorrente.removeAttrezzo(attrezzoTrovato.getNome());
		partita.getGiocatore().addAttrezzo(attrezzoTrovato);
		this.getIO().mostraMessaggio("Raccolto " + attrezzoTrovato.getNome() + ".");
		
	}

//	@Override
//	public void setParametro(String attrezzo) {
//		this.attrezzo = attrezzo;
//	}
//	
//	
//	@Override
//	public void setIO (IO ioConsole) {
//		this.ioConsole = ioConsole;		
//	}
//
//	@Override
//	public String getNome() {
//		// TODO Auto-generated method stub
//		return "prendi";
//	}
//
//	@Override
//	public void getParametro() {
//		// TODO Auto-generated method stub
//		
//	}

}
