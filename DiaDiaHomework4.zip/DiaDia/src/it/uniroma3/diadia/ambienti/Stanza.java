package it.uniroma3.diadia.ambienti;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.personaggi.AbstractPersonaggio;

/**
 * Classe Stanza - una stanza in un gioco di ruolo.
 * Una stanza e' un luogo fisico nel gioco.
 * E' collegata ad altre stanze attraverso delle uscite.
 * Ogni uscita e' associata ad una direzione.
 * 
 * @author docente di POO 
 * @see Attrezzo
 * @version base
 */

public class Stanza {
	static final private int NUMERO_MASSIMO_ATTREZZI = 10;

	private String descrizione;
	private Map<String, Attrezzo> nome2attrezzo;	
	private Map<Direzione, Stanza> direzione2stanzeAdiacenti;
	private AbstractPersonaggio personaggio;
	private int counterAttrezzi;
	/**
	 * Crea una stanza. Non ci sono stanze adiacenti, non ci sono attrezzi.
	 * @param nome il nome della stanza
	 */
	public Stanza(String descrizione){
		this.direzione2stanzeAdiacenti = new HashMap<>();
		this.nome2attrezzo = new HashMap<>();
		this.descrizione = descrizione;
		this.setCounterAttrezzi(0);
	}
	
	public Map<Direzione, Stanza> getDirezione2StanzeAdiacenti() {
		return this.direzione2stanzeAdiacenti;
	}

	public Stanza getStanzaAdiacente(Direzione direzione) {
		return this.direzione2stanzeAdiacenti.get(direzione);
	}


	public void impostaStanzaAdiacente(String direzione, Stanza stanzaAdiacente) {
		this.direzione2stanzeAdiacenti.put(Direzione.valueOf(direzione.toUpperCase()),stanzaAdiacente);
	}

	public int getNumeroAttrezzi() {
		return this.getAttrezzi().size();
	}


	/**
	 * Restituisce la nome della stanza.
	 * @return il nome della stanza
	 */
	public String getNome() {
		return this.descrizione;
	}

	/**
	 * Restituisce l'attrezzo nomeAttrezzo se presente nella stanza.
	 * @param nomeAttrezzo
	 * @return l'attrezzo presente nella stanza.
	 * 		   null se l'attrezzo non e' presente.
	 */

	public Attrezzo getAttrezzo(String nomeAttrezzo) {
		return nome2attrezzo.get(nomeAttrezzo);
	}

	/**
	 * Restituisce la descrizione della stanza.
	 * @return la descrizione della stanza
	 */
	public String getDescrizione() {
		return this.toString();
	}

	/**
	 * Restituisce la collezione di attrezzi presenti nella stanza.
	 * @return la collezione di attrezzi nella stanza.
	 */
	public Collection<Attrezzo> getAttrezzi() {
		return this.nome2attrezzo.values();
	}

	public String getDirezioni() {
		return this.direzione2stanzeAdiacenti.keySet().toString();
	}
	
	public int getCounterAttrezzi() {
		return counterAttrezzi;
	}

	public AbstractPersonaggio getPersonaggio() {
		return this.personaggio;
	}

	public void setPersonaggio(AbstractPersonaggio personaggio) {
		this.personaggio = personaggio;
	}
	
	public void setCounterAttrezzi(int counterAttrezzi) {
		this.counterAttrezzi = counterAttrezzi;
	}

	public boolean hasAttrezzo(String chiave) {
		return this.nome2attrezzo.containsKey(chiave);

	}


	public boolean addAttrezzo(Attrezzo attrezzo) {
		if ( nome2attrezzo.size() == NUMERO_MASSIMO_ATTREZZI )
			return false ;
		nome2attrezzo.put(attrezzo.getNome(), attrezzo);
		this.setCounterAttrezzi(this.getCounterAttrezzi() + 1);
		return true;
	}

	public boolean removeAttrezzo(String nomeAttrezzo) {
		if( ! nome2attrezzo.containsKey( nomeAttrezzo ) )
			return false;

		nome2attrezzo.remove(nomeAttrezzo);
		this.setCounterAttrezzi(this.getCounterAttrezzi() - 1);
		return true;
	}

	public boolean isEmpty() {
		return nome2attrezzo.isEmpty();
	}

	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append(this.descrizione);
		s.append("\nUscite: ");

		s.append(this.direzione2stanzeAdiacenti.keySet().toString() + "\n");

		if (! this.isEmpty() ) {
			s.append("Attrezzi nella stanza: ");
			s.append(nome2attrezzo.values().toString() + "\n");
		}
		else 
			s.append("Stanza vuota." + "\n");
		
		if (this.getPersonaggio() == null)
			s.append("Qui non c'e' nessuno." + "\n");
		else {
			s.append("Sei in compagnia di ");
			s.append(this.getPersonaggio().getNome() + ".\n");
		}
		return s.toString();
	}


}












