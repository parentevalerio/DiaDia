package it.uniroma3.diadia.ambienti;

import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.IOConsole;

public class StanzaBloccata extends Stanza {

	final static private String CHIAVE_DEFAULT = "chiave";
	final static private Direzione DIREZIONE_BLOCCATA_DEFAULT = Direzione.EST;
	
	private IO ioConsole;
	private String chiave;
	private Direzione direzioneBloccata;
	
	public StanzaBloccata(String nome) {
		this(nome, CHIAVE_DEFAULT, DIREZIONE_BLOCCATA_DEFAULT);
		
	}

	public StanzaBloccata(String nome, String chiave, Direzione direzioneBloccata) {
		super(nome);
		this.chiave = chiave;
		this.direzioneBloccata = direzioneBloccata;
	}
	
	@Override
	public Stanza getStanzaAdiacente(Direzione dir) {
		
		if (this.direzioneBloccata.equals(dir)) {
		if ( this.hasAttrezzo(this.chiave) == false  )
			return this;}
		
		return super.getStanzaAdiacente(dir);
	}
	
	@Override 
	public String getDescrizione() {
		ioConsole = new IOConsole();
		ioConsole.mostraMessaggio("La stanza � bloccata");
		return super.getDescrizione();
	}
	
	

}
