package it.uniroma3.diadia.ambienti;

public class StanzaBuia extends Stanza {

	final static private String ATTREZZO_DEFAULT = "lanterna";
	final static private String BUIO_PESTO = "Qui c'� un buio pesto";
	private String attrezzo;
	
	public StanzaBuia(String nome) {
		this(nome, ATTREZZO_DEFAULT);
	}
	
	public StanzaBuia(String nome, String attrezzoBuio) {
		super(nome);
		this.attrezzo = attrezzoBuio;
	}
	public String getBuioPesto() {
		return BUIO_PESTO;
	}
	
	@Override
	public String getDescrizione() {
		
		if ( this.hasAttrezzo(this.attrezzo) )		
			return super.getDescrizione();
		return BUIO_PESTO;
		
	}
}
