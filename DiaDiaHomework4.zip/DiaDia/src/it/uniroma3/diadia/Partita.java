package it.uniroma3.diadia;

import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.giocatore.Giocatore;

/**
 * Questa classe modella una partita del gioco
 *
 * @author  docente di POO
 * @see Stanza
 * @version base
 */

public class Partita {



	private Stanza stanzaCorrente;
	private Stanza stanzaVincente;
	private boolean finita;
	
	private Giocatore giocatore;
	private Labirinto labirinto;
	
	public Giocatore getGiocatore() {
		return this.giocatore;
	}
	
	public Labirinto getlabirinto() {
		return this.labirinto;
	}


	public Partita(Labirinto labirinto) {
		this.labirinto = labirinto;
		this.giocatore = new Giocatore();
		this.setStanzaCorrente(labirinto.getStanzaIniziale());
		this.setStanzaVincente(labirinto.getStanzaVincente());
		this.finita = false;
	}

    /**
     * Crea tutte le stanze e le porte di collegamento
     */
	
	public boolean getFinita() {
		return this.finita;
	}
	
	public Stanza getStanzaCorrente() {
		return this.stanzaCorrente;
	}
	
	public Stanza getStanzaVincente() {
		return stanzaVincente;
	}

	public void setStanzaCorrente(Stanza stanzaCorrente) {
		this.stanzaCorrente = stanzaCorrente;
	}
	
	public void setStanzaVincente(Stanza stanzaVincente) {
		this.stanzaVincente = stanzaVincente;
	}

	public void setLabirinto(Labirinto labirinto) {
		this.labirinto = labirinto;
	}
	
	/**
	 * Imposta la partita come finita
	 *
	 */
	public void setFinita() {
		this.finita = true;
	}
	

	/**
	 * Restituisce vero se e solo se la partita e' stata vinta
	 * @return vero se partita vinta
	 */
	public boolean vinta() {
		return this.getStanzaCorrente().getNome().equals(this.getStanzaVincente().getNome());
	}

	/**
	 * Restituisce vero se e solo se la partita e' finita
	 * @return vero se partita finita
	 */
	public boolean isFinita() {
		return this.getFinita() || this.vinta() || (getGiocatore().getCfu() == 0);
	}
	
	public boolean giocatoreIsVivo() {
		return this.getGiocatore().isVivo();
	}
	
}














