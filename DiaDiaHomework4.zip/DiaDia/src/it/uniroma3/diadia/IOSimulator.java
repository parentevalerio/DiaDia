package it.uniroma3.diadia;

import java.util.HashMap;
import java.util.Map;

public class IOSimulator implements IO {

	private Map<Integer, String> righeDaLeggere;
	private int indiceRigheDaLeggere;
	private Map<Integer, String> messaggiProdotti;
	private int indiceMessaggiProdotti;
	private int indiceMessaggiMostrati;
	
	public IOSimulator (Map<Integer, String> righeDaLeggere) {
		this.righeDaLeggere = righeDaLeggere;
		this.indiceRigheDaLeggere = 0;
		this.messaggiProdotti = new HashMap<>();
		this.indiceMessaggiProdotti = 0;
		this.indiceMessaggiMostrati = 0;
	}
	
	@Override
	public void mostraMessaggio(String messaggio) {
        this.messaggiProdotti.put(indiceMessaggiProdotti, messaggio);
		
//		this.messaggiProdotti[this.indiceMessaggiProdotti] = messaggio;
		this.indiceMessaggiProdotti ++;
		
	}

	@Override
	public String leggiRiga() {
		String rigaLetta = this.righeDaLeggere.get(indiceRigheDaLeggere);
		this.indiceRigheDaLeggere++;
		return rigaLetta;
	}
	
	public String nextMessaggio() {
		String next =  this.messaggiProdotti.get(indiceMessaggiMostrati);
		this.indiceMessaggiMostrati++;
		return next;
	}
	
	public boolean hasNextMessaggio() {
		return this.indiceMessaggiMostrati < this.indiceMessaggiProdotti ;
	}
}
