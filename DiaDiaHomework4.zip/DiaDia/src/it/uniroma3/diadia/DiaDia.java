package it.uniroma3.diadia;




import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.comandi.AbstractComando;
import it.uniroma3.diadia.comandi.FabbricaDiComandi;
import it.uniroma3.diadia.comandi.FabbricaDiComandiRiflessiva;

/**
 * Classe principale di diadia, un semplice gioco di ruolo ambientato al dia.
 * Per giocare crea un'istanza di questa classe e invoca il letodo gioca
 *
 * Questa e' la classe principale crea e istanzia tutte le altre
 *
 * @author  docente di POO 
 *         (da un'idea di Michael Kolling and David J. Barnes) 
 *          
 * @version base
 */

public class DiaDia {

	static final private String MESSAGGIO_BENVENUTO = ""+
			"Ti trovi nell'Universita', ma oggi e' diversa dal solito...\n" +
			"Meglio andare al piu' presto in biblioteca a studiare. Ma dov'e'?\n"+
			"I locali sono popolati da strani personaggi, " +
			"alcuni amici, altri... chissa!\n"+
			"Ci sono attrezzi che potrebbero servirti nell'impresa:\n"+
			"puoi raccoglierli, usarli, posarli quando ti sembrano inutili\n" +
			"o regalarli se pensi che possano ingraziarti qualcuno.\n\n"+
			"Per conoscere le istruzioni usa il comando 'aiuto'.";
	
	public static String getMessaggioBenvenuto() {
		return MESSAGGIO_BENVENUTO;
	}


	private Partita partita;
	
	public DiaDia(IO io, Labirinto labirinto) {
		this.partita = new Partita(labirinto);
		
	}

	public void gioca(IO ioConsole) {
		String istruzione; 
				
		ioConsole.mostraMessaggio(getMessaggioBenvenuto());
		
		do	
			istruzione = ioConsole.leggiRiga();
				
		while (!processaIstruzione(istruzione, ioConsole));
		
	}   

	/**
	 * Processa una istruzione 
	 *
	 * @return true se l'istruzione e' eseguita e il gioco continua, false altrimenti
	 */
	private boolean processaIstruzione(String istruzione, IO ioConsole) {
		AbstractComando comandoDaEseguire = null;
		FabbricaDiComandi factory = new FabbricaDiComandiRiflessiva();
		try {
			comandoDaEseguire = factory.costruisciComando(istruzione, ioConsole);
		} catch (Exception e) {
			//new instance comando non valido?
			e.printStackTrace();
		}
		comandoDaEseguire.esegui(this.partita);
		if (this.partita.vinta())

		ioConsole.mostraMessaggio("Hai vinto!");
		if (!this.partita.giocatoreIsVivo())

		ioConsole.mostraMessaggio("Hai esaurito i CFU...");

		return this.partita.isFinita();
		}

	
	public static void main(String[] argc)  {
		IO io = new IOConsole();
		
		Labirinto labirinto = Labirinto.newBuilder()
		.addStanzaVincente("Biblioteca")
		.addStanzaIniziale("Atrio")
		.addAttrezzo("Atrio","osso", 2)
		.addStanza("Aula N11")
		.addStrega("Strega", " BAKA!","Aula N11")
		.addAttrezzo("Aula N11","lanterna", 3)
		.addStanza("Aula N10")
		.addAttrezzo("Aula N10","kiwi", 1)
		.addAttrezzo("Aula N10","piuma", 0)
		.addAttrezzo("Aula N10","piombo", 10)
		.addStanza("Laboratorio Campus")
		.addAttrezzo("Laboratorio Campus","avocado", 1)
		.addAttrezzo("Laboratorio Campus","ps", 5)
		.addStanza("Biblioteca")
		.addStanzaMagica("Stanza Magica")
		.addStanzaBuia("Stanza Buia")
		.addCane("Doggo", "GRR", "chiave", 0, "osso","Stanza Buia")
		.addStanzaBloccata("Stanza Bloccata", "chiave", "nord")
		.addStanza("Stanza Locked")
		.addMago("Mago Torta", " Cakez", "torta", 3,"Stanza Locked")
		
		.addAdiacenza("Atrio","Biblioteca" ,"nord")
		.addAdiacenza("Atrio", "Aula N11" ,"est" )
		.addAdiacenza("Atrio", "Aula N10" ,"sud" )
		.addAdiacenza("Atrio", "Laboratorio Campus" ,"ovest" )
		
		.addAdiacenza("Aula N11", "Atrio" ,"ovest" )
		.addAdiacenza("Aula N11", "Laboratorio Campus" ,"est" )
		
		.addAdiacenza("Aula N10", "Atrio" ,"nord" )
		.addAdiacenza("Aula N10", "Aula N11" ,"est" )
		.addAdiacenza("Aula N10", "Laboratorio Campus" ,"ovest" )

		.addAdiacenza("Laboratorio Campus", "Atrio" ,"est" )
		.addAdiacenza("Laboratorio Campus", "Aula N11" ,"ovest" )
		.addAdiacenza("Laboratorio Campus", "Stanza Magica" ,"nord" )

		.addAdiacenza("Stanza Magica", "Laboratorio Campus" ,"sud" )
		.addAdiacenza("Stanza Magica", "Stanza Buia" ,"ovest" )
		.addAdiacenza("Stanza Magica", "Stanza Bloccata" ,"est" )
		
		.addAdiacenza("Stanza Buia", "Stanza Magica" ,"est" )
		
		.addAdiacenza("Stanza Bloccata", "Stanza Magica" ,"ovest" )
		.addAdiacenza("Stanza Bloccata", "Stanza Locked" ,"nord" )
		
		.addAdiacenza("Stanza Locked", "Stanza Bloccata" ,"sud" )

		.addAdiacenza("Biblioteca", "Atrio" ,"sud" )
		.getLabirinto();

		DiaDia gioco = new DiaDia(io,labirinto);
		try {
			gioco.gioca(io);
		} catch (Exception e) {
			io.mostraMessaggio("Errore inaspettato");;
		}
		
		
	}


}
















