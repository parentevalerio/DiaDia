package it.uniroma3.diadia.giocatore;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import it.uniroma3.diadia.ConfigurazioniIniziali;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class Borsa {
	//borsa pesnsata come Map dove le chiavi sono i nomi degli attrezzi e i valori
	//corrispondenti sono gli attrezzi.
	public final static int DEFAULT_PESO_MAX_BORSA = ConfigurazioniIniziali.getPesoMax();
	private Map<String, Attrezzo> nome2attrezzo;
	private int pesoMax;
	private int pesoAttuale;

	//default constructor.
	public Borsa() {
		this(DEFAULT_PESO_MAX_BORSA);
	}

	//costruttore di borsa.
	public Borsa(int pesoMax) {
		this.pesoMax = pesoMax;
		nome2attrezzo = new HashMap<>();
	}

	//ritorna una lista di tutti gli attrezzi.
	public Collection<Attrezzo> getAttrezzi(){
		return nome2attrezzo.values();
	}

	//ritorna il l'attrezzo cercato per nome.
	public Attrezzo getAttrezzo(String nomeAttrezzo) {
		return nome2attrezzo.get(nomeAttrezzo);
	}

	public int getPesoMax() {
		return pesoMax;
	}

	//ritorna il peso attuale della borsa.
	public int getPeso() {
		return pesoAttuale;
	}

	public List<Attrezzo> getContenutoOrdinatoPerPeso(){
		List<Attrezzo> lista = new LinkedList<>();
		lista.addAll(nome2attrezzo.values());
		ComparatoreAttrezziPerPeso comparatore = new ComparatoreAttrezziPerPeso();
		lista.sort(comparatore);
		return lista;
	}


	public SortedSet<Attrezzo> getContenutoOrdinatoPerNome(){
		return new TreeSet <>(nome2attrezzo.values());

	}

	public Map<Integer, Set<Attrezzo>> getContenutoRaggruppatoPerPeso(){
		Map<Integer,Set<Attrezzo>> mappa = new HashMap<>();
		for (Attrezzo attrezzo : nome2attrezzo.values()) {
			Set<Attrezzo> setAttrezziPerPeso = mappa.get(attrezzo.getPeso());
			if (setAttrezziPerPeso == null) {
				setAttrezziPerPeso = new TreeSet<>();
				mappa.put(attrezzo.getPeso(), setAttrezziPerPeso);
			}
			setAttrezziPerPeso.add(attrezzo);
		}
		return mappa;
	}



	public SortedSet<Attrezzo> getSortedSetOrdinatoPerPeso(){
		SortedSet<Attrezzo> sortedSet = new TreeSet<>(new ComparatoreAttrezziPerPeso());
		sortedSet.addAll(nome2attrezzo.values());
		return sortedSet;
	}


	//controlla se la mappa � vuota o no
	public boolean isEmpty() {
		return nome2attrezzo.isEmpty();
	}

	//verifica se un attrezzo � contenuto nella borsa.
	public boolean hasAttrezzo(String nomeAttrezzo) {
		return this.getAttrezzo(nomeAttrezzo) != null;
	}

	//aggiunge un attrezzo nella borsa, controlla prima se il peso massimo
	//eccederebbe con l'aggiunta dell'oggetto, in tal caso ritorna false.
	//se l'attrezzo � aggiunto, alla fine aggiorna il peso attuale.
	public boolean addAttrezzo(Attrezzo attrezzo) {
		if ( this.getPeso() + attrezzo.getPeso() > this.getPesoMax() )
			return false ;
		nome2attrezzo.put(attrezzo.getNome(), attrezzo);
		pesoAttuale += attrezzo.getPeso();
		return true;
	}

	//rimuove un attrezzo dalla borsa, controlla prima se non � presente,
	//in tal caso ritorna false.
	//se l'attrezzo � rimosso, alla fine aggiorna il peso attuale.
	public boolean removeAttrezzo(String nomeAttrezzo) {
		if( ! nome2attrezzo.containsKey(nomeAttrezzo ) )
			return false;

		pesoAttuale -= nome2attrezzo.get(nomeAttrezzo).getPeso();
		nome2attrezzo.remove(nomeAttrezzo);
		return true;
	}

	//ritorna la descrizione della borsa
	public String toString() {
		StringBuilder s = new StringBuilder();
		if (! this.isEmpty()) {
			s.append("Contenuto borsa (" + pesoAttuale + " kg/" + this.getPesoMax() +"kg): ");
			s.append(nome2attrezzo.values().toString());
		}
		else 
			s.append("Borsa vuota.");
		return s.toString();
	}

}

//	private List<Attrezzo> attrezzi;
//	private int pesoMax = 10 ;
//
//
//	
//	public Borsa() {
//		this.attrezzi = new ArrayList<Attrezzo>();
//	}
//
//	
//	public List<Attrezzo> getAttrezzi() {
//		return this.attrezzi;
//	}
//
//	/**	 
//	 * Ritorna la somma del peso di tutti gli attrezzi nella borsa 
//	 *
//	 * @return peso totale della borsa 
//	 **/
//	public int getPeso(){
//
//		int pesoTotale = 0;
//
//		for(Attrezzo a : this.attrezzi)
//			pesoTotale += a.getPeso();
//
//		return pesoTotale;
//	}
//	
//	public int getPesoMax(){
//
//		return this.pesoMax ;
//	}
//	
//
//	/**	 
//	 * Ritorna il numero di tutti gli attrezzi nella borsa 
//	 *
//	 * @return contatore del numero di attrezzi nella borsa
//	 **/
//	public int getNumeroAttrezzi() {
//		int count=0;
//		Iterator<Attrezzo> iteratore = this.attrezzi.iterator();
//
//		while (iteratore.hasNext()) {
//			iteratore.next();
//			count++;
//		}
//
//		return count ;
//	}
//
//	public Attrezzo getAttrezzo(String nomeAttrezzo) {
//		Attrezzo a = null;
//		a = new Attrezzo(nomeAttrezzo, 0);
//		if ( !this.getAttrezzi().isEmpty() ) {
//		a = this.getAttrezzi().get( this.getIndiceAttrezzo(a.getNome()) );
//		}
//		return a;
//	}
//
//
//	public int getIndiceAttrezzo(String nomeAttrezzo) {
//		
//		Attrezzo prototipo = this.getAttrezzo(nomeAttrezzo);
//		int indice;
//		indice = this.getAttrezzi().indexOf(prototipo);
//		return indice; 
//	
//	}
//
//	public boolean addAttrezzo(Attrezzo attrezzo) {
//		return this.getAttrezzi().add(attrezzo);
//	}
//
//	/**	 
//	 * Rimuove un attrezzo dalla borsa 
//	 *
//	 * @return true se l'istruzione e' eseguita, false altrimenti 
//	 **/
//	public Attrezzo removeAttrezzo(String nomeAttrezzo) {
//		Attrezzo a = null;
//		Iterator<Attrezzo> iteratore = this.attrezzi.iterator();
//		while (iteratore.hasNext()) {
//			a = iteratore.next();
//			if (a.getNome().equals(nomeAttrezzo)) {
//
//				iteratore.remove();
//				return a;
//			}
//		}
//		return null;
//	}
//
//	public boolean hasAttrezzo(String nomeAttrezzo) {
//		return this.getAttrezzo(nomeAttrezzo)!=null;
//	}
//	
//	
//	public String toString() {
//		StringBuilder s = new StringBuilder();
//		if (!this.getAttrezzi().isEmpty()) {
//				s.append("Contenuto borsa ("+this.getPeso()+"kg/"+this.getPesoMax()+"kg): ");
//				
//				Attrezzo a = null;
//				Iterator<Attrezzo> iteratore = this.getAttrezzi().iterator();
//				a = this.getAttrezzi().get(0);
//
//				while (iteratore.hasNext()) {
//					s.append(a.toString()+" ");
//					a = iteratore.next();
//				}	
//	//			for (int i = 0; i < this.getAttrezzi().length; i++) {
//	//				if (this.getAttrezzi()[i] != null) {
//	//					s.append(this.getAttrezzi()[i].toString()+" ");
//	//				}
//	//			}
//			}
//			else
//				s.append("Borsa vuota.");
//			return s.toString();
//		}




//	public final static int DEFAULT_PESO_MAX_BORSA = 10;
//	private Attrezzo[] attrezzi;
//	private int numeroAttrezzi;
//	private int pesoMax;
//	
//	public Borsa() {
//		this(DEFAULT_PESO_MAX_BORSA);
//	}
//	
//	public Borsa(int pesoMax) {
//		this.pesoMax = pesoMax;
//		this.attrezzi = new Attrezzo[10]; 
//		this.numeroAttrezzi = 0;
//	}
//	
//	public Attrezzo[] getAttrezzi() {
//		return this.attrezzi;
//	}
//	
//	public int getNumeroAttrezzi() {.........
//		return this.numeroAttrezzi;
//	}
//	
//	public int getPesoMax() {
//		return this.pesoMax;
//	}
//	
//	public Attrezzo getAttrezzo(String nomeAttrezzo) {
//		Attrezzo a = null;
//		for (int i= 0 ; i < this.getAttrezzi().length ; i++) 
//			if (this.getAttrezzi()[i] != null) {
//			if (this.getAttrezzi()[i].getNome().equals(nomeAttrezzo))
//				a = getAttrezzi()[i];
//		}
//		return a;
//	}
//	
//	public int getIndiceAttrezzo(String nomeAttrezzo) {
//		
//		for (int i=0; i < this.getAttrezzi().length; i++) {
//			if (this.getAttrezzi()[i] != null) {
//			if (this.getAttrezzi()[i].getNome().equals(nomeAttrezzo))
//				return i;
//			}
//		}
//		return -1;	
//	}
//
//	public int getPeso() {
//		int peso = 0;
//		for (int i = 0; i < this.getAttrezzi().length; i++) {
//			if (this.getAttrezzi()[i] != null)
//				peso += this.getAttrezzi()[i].getPeso();
//		}
//		return peso;
//	}
//	
//	
//	
//	public void setNumeroAttrezzi(int numeroAttrezzi) {
//		this.numeroAttrezzi=numeroAttrezzi;
//	}
//	
//	public boolean isEmpty() {
//		return this.numeroAttrezzi == 0;
//	}
//	
//	public boolean hasAttrezzo(String nomeAttrezzo) {
//		return this.getAttrezzo(nomeAttrezzo)!=null;
//	}
//		
//	public String toString() {
//		StringBuilder s = new StringBuilder();
//		if (!this.isEmpty()) {
//			s.append("Contenuto borsa ("+this.getPeso()+"kg/"+this.getPesoMax()+"kg): ");
//			for (int i = 0; i < this.getAttrezzi().length; i++) {
//				if (this.getAttrezzi()[i] != null) {
//					s.append(this.getAttrezzi()[i].toString()+" ");
//				}
//			}
//		}
//		else
//			s.append("Borsa vuota.");
//		return s.toString();
//	}













