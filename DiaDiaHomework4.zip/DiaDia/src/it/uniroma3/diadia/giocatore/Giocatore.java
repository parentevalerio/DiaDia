package it.uniroma3.diadia.giocatore;

import it.uniroma3.diadia.ConfigurazioniIniziali;
import it.uniroma3.diadia.attrezzi.Attrezzo;

/**
 * Questa classe modella una giocatore. Gestisce i CFU del
 * giocatore e la memorizzazione degli attrezzi nella borsa
 *
 * @version base
 */


public class Giocatore {
	
	static final private int CFU_INIZIALI = ConfigurazioniIniziali.getCFU();
	private int cfu;
	private Borsa borsa;
	
	
	
	public void setCfu(int cfu) {
		this.cfu = cfu;		
	}	
	
	public void setBorsa(Borsa borsa) {
		this.borsa = borsa;
	}
	
	public Borsa getBorsa() {
		return this.borsa;
	}
	
	
	public int getCfu() {
		return this.cfu ;
	}


	public Giocatore() {
		this.cfu = CFU_INIZIALI;
		this.borsa= new Borsa();
	}

	public boolean addAttrezzo(Attrezzo attrezzo) {
		if (attrezzo == null)
			throw new java.util.NoSuchElementException();
		 
	return	this.getBorsa().addAttrezzo(attrezzo);

		
	}

	
	/**
	 * Rimuove un attrezzo dalla borsa, supponendo che questo esista (ricerca in base al nome).
	 * @param attrezzo
	 * @return true se l'attrezzo e' stato rimosso, false altrimenti
	 */
	public boolean removeAttrezzo(Attrezzo attrezzo) {
		if (attrezzo == null)
			throw new java.util.NoSuchElementException();
			
			return this.getBorsa().removeAttrezzo(attrezzo.getNome());
		}
	
	public boolean isVivo() {
		return this.cfu > 0;
	}
	
}

//
//public class Giocatore {
//	
//	static final private int CFU_INIZIALI = 20;
//	private int cfu;
//	private Borsa borsa;
//	
//	
//	
//	public void setCfu(int cfu) {
//		this.cfu = cfu;		
//	}	
//	
//	public void setBorsa(Borsa borsa) {
//		this.borsa = borsa;
//	}
//	
//	public Borsa getBorsa() {
//		return this.borsa;
//	}
//	
//	
//	public int getCfu() {
//		return this.cfu ;
//	}
//
//
//	public Giocatore() {
//		this.cfu = CFU_INIZIALI;
//		this.borsa= new Borsa();
//	}
//
//	public boolean addAttrezzo(Attrezzo attrezzo) {
//		if (attrezzo == null)
//			throw new java.util.NoSuchElementException();
//		
//		for (int i = 0; i < this.getBorsa().getAttrezzi().length; i++) {
//			if ( this.getBorsa().getAttrezzi()[i] == null ) {
//				this.getBorsa().getAttrezzi()[i] = attrezzo;
//				this.getBorsa().setNumeroAttrezzi(this.getBorsa().getNumeroAttrezzi() + 1);
//				return true;
//			}
//		}
//		return false;
//	}
//	
//	/**
//	 * Rimuove un attrezzo dalla borsa, supponendo che questo esista (ricerca in base al nome).
//	 * @param attrezzo
//	 * @return true se l'attrezzo e' stato rimosso, false altrimenti
//	 */
//	public boolean removeAttrezzo(Attrezzo attrezzo) {
//		if (attrezzo == null)
//			throw new java.util.NoSuchElementException();
//		
//		
//		int indiceAttrezzo = this.getBorsa().getIndiceAttrezzo(attrezzo.getNome());
//		if (indiceAttrezzo == -1) {
//			return false;
//		}
//		else {
//			this.getBorsa().getAttrezzi()[indiceAttrezzo] = null;
//			this.getBorsa().setNumeroAttrezzi(this.getBorsa().getNumeroAttrezzi() - 1);
//			return true;
//		}
//	}
//	
//	public boolean isVivo() {
//		return this.cfu > 0;
//	}
//	
//}
//

