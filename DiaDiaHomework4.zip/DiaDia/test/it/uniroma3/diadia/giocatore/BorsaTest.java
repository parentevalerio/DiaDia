package it.uniroma3.diadia.giocatore;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.attrezzi.Attrezzo;

public class BorsaTest {
	private Borsa borsa;
	private Borsa borsaVuota;
	private Borsa borsaMap;
	
	private Attrezzo attrezzo;
	private Attrezzo attrezzoA;
	private Attrezzo attrezzoB;
	private Attrezzo attrezzoC;
	private Attrezzo attrezzoD;
	private Attrezzo attrezzoE;
	
	private Map<String, Attrezzo> nome2attrezzoDummy;
	private List<Attrezzo> listaDummyOrdinatoPerPeso;
	private SortedSet<Attrezzo> treeSetDummyOrdinatoPerNome;
	private Map< Integer, Set<Attrezzo> > mapDummyContenutoRaggruppatoPerPeso;	
	private SortedSet<Attrezzo> sortedSetDummyOrdinatoPerPeso;
	private Set<Attrezzo> setA;
	private Set<Attrezzo> setB;
	private Set<Attrezzo> setC;
	private Set<Attrezzo> setD;
	
	@Before
	public void setUp() {
		this.borsa = new Borsa(10);
		this.borsaVuota = new Borsa(10);
		this.borsaMap = new Borsa(10);
		this.attrezzo = new Attrezzo("attrezzo", 1);
		this.borsa.addAttrezzo(attrezzo);


		this.attrezzoA = new Attrezzo("a", 0);
		this.attrezzoB = new Attrezzo("b", 1);
		this.attrezzoC = new Attrezzo("c", 2);
		this.attrezzoD = new Attrezzo("d", 3);
		this.attrezzoE = new Attrezzo("e", 3);
		
		this.borsaMap.addAttrezzo(attrezzoE);
		this.borsaMap.addAttrezzo(attrezzoB);
		this.borsaMap.addAttrezzo(attrezzoA);
		this.borsaMap.addAttrezzo(attrezzoD);
		this.borsaMap.addAttrezzo(attrezzoC);
		
		//setUp
		this.nome2attrezzoDummy = new HashMap<>();
		this.nome2attrezzoDummy.put("e", attrezzoE);
		this.nome2attrezzoDummy.put("b", attrezzoB);
		this.nome2attrezzoDummy.put("a", attrezzoA);
		this.nome2attrezzoDummy.put("d", attrezzoD);
		this.nome2attrezzoDummy.put("c", attrezzoC);
		//setUp
		this.listaDummyOrdinatoPerPeso = new LinkedList<>();
		this.listaDummyOrdinatoPerPeso.add(attrezzoA);
		this.listaDummyOrdinatoPerPeso.add(attrezzoB);
		this.listaDummyOrdinatoPerPeso.add(attrezzoC);
		this.listaDummyOrdinatoPerPeso.add(attrezzoD);
		this.listaDummyOrdinatoPerPeso.add(attrezzoE);
		//setUp		
		this.sortedSetDummyOrdinatoPerPeso = new TreeSet<>(new ComparatoreAttrezziPerPeso());
		this.sortedSetDummyOrdinatoPerPeso.addAll( nome2attrezzoDummy.values() );
		//setUp
		this.mapDummyContenutoRaggruppatoPerPeso = new HashMap<>();
		setA = new TreeSet<>();
		setB = new TreeSet<>();
		setC = new TreeSet<>();
		setD = new TreeSet<>();
		setA.add(attrezzoA);
		setB.add(attrezzoB);
		setC.add(attrezzoC);
		setD.add(attrezzoD);
		setD.add(attrezzoE);
		
		this.mapDummyContenutoRaggruppatoPerPeso.put(0, setA);
		this.mapDummyContenutoRaggruppatoPerPeso.put(1, setB);
		this.mapDummyContenutoRaggruppatoPerPeso.put(2, setC);
		this.mapDummyContenutoRaggruppatoPerPeso.put(3, setD);
		this.mapDummyContenutoRaggruppatoPerPeso.put(3, setD);
		//setUp
		this.treeSetDummyOrdinatoPerNome = new TreeSet<>();
		this.treeSetDummyOrdinatoPerNome.add(attrezzoA);
		this.treeSetDummyOrdinatoPerNome.add(attrezzoB);
		this.treeSetDummyOrdinatoPerNome.add(attrezzoD);
		this.treeSetDummyOrdinatoPerNome.add(attrezzoC);
		this.treeSetDummyOrdinatoPerNome.add(attrezzoE);
		
	}
	
	@Test
	public void testGetAttrezzoPresente() {
		assertSame(attrezzo, this.borsa.getAttrezzo("attrezzo"));
	}
	
	@Test
	public void testGetAttrezzoNonPresente() {
		assertSame(null, this.borsaVuota.getAttrezzo("attrezzo"));
	}
	
	@Test
	public void testGetPesoBorsaVuota() {
		assertEquals(0,this.borsaVuota.getPeso());
	}
	
	@Test
	public void testGetPesoBorsaNonVuota() {
		assertEquals(1,this.borsa.getPeso());
	}
	
	@Test
	public void testGetIndiceAttrezzoPresente() {
		assertTrue ( this.borsa.hasAttrezzo("attrezzo") );
	}
	
	@Test
	public void testGetIndiceAttrezzoNonPresente() {
		assertFalse ( this.borsaVuota.hasAttrezzo("attrezzo") );
	}
	
	@Test
	public void testgetContenutoOrdinatoPerPeso() {
		assertEquals( this.listaDummyOrdinatoPerPeso, 
				this.borsaMap.getContenutoOrdinatoPerPeso());
	}
	
	@Test
	public void testgetContenutoOrdinatoPerNome() {
		assertEquals( this.treeSetDummyOrdinatoPerNome, 
				this.borsaMap.getContenutoOrdinatoPerNome());
	}

	@Test
	public void testgetContenutoOrdinatoRaggruppatoPerPeso() {
		assertEquals( this.mapDummyContenutoRaggruppatoPerPeso, 
				this.borsaMap.getContenutoRaggruppatoPerPeso());
	}

	@Test
	public void testgetContenutoSortedSetOrdinatoPerPeso() {
		assertEquals( this.sortedSetDummyOrdinatoPerPeso, 
				this.borsaMap.getSortedSetOrdinatoPerPeso());
	}


}
	





















