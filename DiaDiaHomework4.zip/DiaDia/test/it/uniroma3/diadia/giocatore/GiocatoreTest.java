package it.uniroma3.diadia.giocatore;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


import it.uniroma3.diadia.attrezzi.Attrezzo;

public class GiocatoreTest {
	

	private Attrezzo attrezzoDummy;
//	private Attrezzo attrezzoDummy2;
//	private Attrezzo attrezzoDummy3;
//	private Attrezzo attrezzoDummy4;
//	private Attrezzo attrezzoDummy5;
//	private Attrezzo attrezzoDummy6;
//	private Attrezzo attrezzoDummy7;
//	private Attrezzo attrezzoDummy8;
//	private Attrezzo attrezzoDummy9;
//	private Attrezzo attrezzoDummy10;
//	private Attrezzo attrezzoDummy11;
//
//	private Attrezzo attrezzoDummyBP;

	private Giocatore giocatoreSenzaAttrezzi;
	private Giocatore giocatoreConUnAttrezzo;
	private Giocatore giocatoreConBorsaPiena;
	private Borsa borsaPiena;
	private Borsa borsaConUnAttrezzo;
	private Borsa borsaSenzaAttrezzi;
	
	private Borsa riempiBorsa(Borsa borsaDaRiempire) {
		
		Attrezzo attrezzoDummy = new Attrezzo ("attrezzoDummy", 0);
//		Attrezzo attrezzoDummy2 = new Attrezzo ("attrezzoDummy2", 0);
//		Attrezzo attrezzoDummy3 = new Attrezzo ("attrezzoDummy3", 0);
//		Attrezzo attrezzoDummy4 = new Attrezzo ("attrezzoDummy4", 0);
//		Attrezzo attrezzoDummy5 = new Attrezzo ("attrezzoDummy5", 0);
//		Attrezzo attrezzoDummy6 = new Attrezzo ("attrezzoDummy6", 0);
//		Attrezzo attrezzoDummy7 = new Attrezzo ("attrezzoDummy7", 0);
//		Attrezzo attrezzoDummy8 = new Attrezzo ("attrezzoDummy8", 0);
//		Attrezzo attrezzoDummy9 = new Attrezzo ("attrezzoDummy9", 0);
//		Attrezzo attrezzoDummy10 = new Attrezzo ("attrezzoDummy10", 0);
		
		borsaDaRiempire.addAttrezzo(attrezzoDummy);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy2);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy3);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy4);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy5);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy6);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy7);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy8);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy9);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy10);
//		borsaDaRiempire.addAttrezzo(attrezzoDummy11);

		return borsaDaRiempire;
	}
	
	@Before
	public void setUp() {
		
	
		this.attrezzoDummy = new Attrezzo("attrezzo dummy", 0);
//		this.attrezzoDummy2 = new Attrezzo("attrezzo dummy2", 0);
//		this.attrezzoDummy3 = new Attrezzo("attrezzo dummy3", 0);
//		this.attrezzoDummy4 = new Attrezzo("attrezzo dummy4", 0);
//		this.attrezzoDummy5 = new Attrezzo("attrezzo dummy5", 0);
//		this.attrezzoDummy6 = new Attrezzo("attrezzo dummy6", 0);
//		this.attrezzoDummy7 = new Attrezzo("attrezzo dummy7", 0);
//		this.attrezzoDummy8 = new Attrezzo("attrezzo dummy8", 0);
//		this.attrezzoDummy9 = new Attrezzo("attrezzo dummy9", 0);
//		this.attrezzoDummy10 = new Attrezzo("attrezzo dummy10", 0);
//		this.attrezzoDummy11 = new Attrezzo("attrezzo dummy11", 0);
//
//		this.attrezzoDummyBP = new Attrezzo("attrezzo dummyBP", 0);

		this.giocatoreConBorsaPiena = new Giocatore();
		this.giocatoreSenzaAttrezzi = new Giocatore();
		this.giocatoreConUnAttrezzo = new Giocatore();
		
		this.borsaPiena = riempiBorsa(new Borsa());    //Modella una borsa sempre piena (con zero posti disponibili)
		this.borsaConUnAttrezzo = new Borsa();   
		this.borsaSenzaAttrezzi = new Borsa();   
		
		this.giocatoreSenzaAttrezzi.setBorsa(this.borsaSenzaAttrezzi);
		this.giocatoreConBorsaPiena.setBorsa(this.borsaPiena );
		this.giocatoreConUnAttrezzo.setBorsa(this.borsaConUnAttrezzo );
		
		this.giocatoreConUnAttrezzo.getBorsa().addAttrezzo(attrezzoDummy);
		
	}
	
	
	@Test
	public void testAddAttrezzo() {
		assertTrue (this.giocatoreSenzaAttrezzi.addAttrezzo(attrezzoDummy));
	}
	
	@Test (expected = java.util.NoSuchElementException.class)
	public void testAddAttrezzoNull() {
		this.giocatoreSenzaAttrezzi.addAttrezzo(null);
	}
	
//	@Test
//	public void testAddAttrezzoConBorsaPiena() {
//		assertFalse (this.giocatoreConBorsaPiena.addAttrezzo(attrezzoDummyBP));
//	}
	
	@Test
	public void testRemoveAttrezzo() {
		assertTrue ( this.giocatoreConUnAttrezzo.removeAttrezzo(attrezzoDummy));
	}
	
	@Test (expected = java.util.NoSuchElementException.class)
	public void testRemoveAttrezzoNull() {
		this.giocatoreConUnAttrezzo.removeAttrezzo(null);
	}
	
		
}
	
	
	
	
	
	
	
	
	
	
	
	
















