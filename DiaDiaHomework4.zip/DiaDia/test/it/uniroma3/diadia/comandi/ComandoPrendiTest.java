package it.uniroma3.diadia.comandi;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.IOConsole;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Borsa;

public class ComandoPrendiTest {

	private Attrezzo attrezzoDummyPesoUnitario;
	private Attrezzo attrezzoDummyPesoDue;
	
	private Stanza stanzaDummy;
	
	private AbstractComando comandoPrendiDummy;
	
	private Partita partitaDummy;
	
	private IOConsole ioConsoleDummy;
	
	private Borsa borsaDummyUnOggetto;
	private Borsa borsaDummyDueOggetti;
	private Borsa borsaDummyVuota;
	
	private Labirinto labirintoDummy;
	

	@Before
	public void setUp() {
		this.attrezzoDummyPesoUnitario = new Attrezzo("attrezzoDummyPesoUnitario", 1);
		this.attrezzoDummyPesoDue = new Attrezzo("attrezzoDummyPesoDue", 2);

		this.stanzaDummy = new Stanza("stanzaDummy");
		this.comandoPrendiDummy = new ComandoPrendi();
		this.ioConsoleDummy = new IOConsole();
		
		this.borsaDummyUnOggetto = new Borsa();
		this.borsaDummyDueOggetti = new Borsa();
		this.borsaDummyVuota = new Borsa();

		this.labirintoDummy = new Labirinto();
		this.partitaDummy = new Partita(labirintoDummy);

	}

	@Test
	public void testPrendiAttrezzoPesoUnitario() {
		
		this.comandoPrendiDummy.setParametro(this.attrezzoDummyPesoUnitario.getNome());
		this.comandoPrendiDummy.setIO( this.ioConsoleDummy );
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyVuota);
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
		this.partitaDummy.getStanzaCorrente().addAttrezzo(attrezzoDummyPesoUnitario);
		
		assertEquals(0 , this.borsaDummyVuota.getPeso());

		this.comandoPrendiDummy.esegui(partitaDummy);
		
		assertEquals(0, this.stanzaDummy.getNumeroAttrezzi());
		
		assertEquals(1 , this.borsaDummyVuota.getPeso());

	}
	
	@Test
	public void testPrendiAttrezzoPesoDue() {
		
		this.comandoPrendiDummy.setParametro(this.attrezzoDummyPesoDue.getNome());
		this.comandoPrendiDummy.setIO( this.ioConsoleDummy );
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyVuota);
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
		this.partitaDummy.getStanzaCorrente().addAttrezzo(attrezzoDummyPesoDue);
		
		assertEquals(0 , this.borsaDummyVuota.getPeso());

		this.comandoPrendiDummy.esegui(partitaDummy);
		
		assertEquals(0, this.stanzaDummy.getNumeroAttrezzi());
		
		assertEquals(2 , this.borsaDummyVuota.getPeso());

	}
	
	@Test
	public void testPrendiAttrezzoPesoUnitarioConBorsaUnOggetto() {
		
		this.comandoPrendiDummy.setParametro(this.attrezzoDummyPesoDue.getNome());
		this.comandoPrendiDummy.setIO( this.ioConsoleDummy );
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyUnOggetto);
		this.borsaDummyUnOggetto.addAttrezzo(attrezzoDummyPesoUnitario);
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
		this.partitaDummy.getStanzaCorrente().addAttrezzo(attrezzoDummyPesoDue);
		
		assertEquals(1 , this.borsaDummyUnOggetto.getPeso());

		this.comandoPrendiDummy.esegui(partitaDummy);
		
		assertEquals(0, this.stanzaDummy.getNumeroAttrezzi());
		
		assertEquals(3 , this.borsaDummyUnOggetto.getPeso());

	}
	
	@Test
	public void testPrendiAttrezzoStanzaVuota() {
		
		this.comandoPrendiDummy.setParametro(this.attrezzoDummyPesoDue.getNome());
		this.comandoPrendiDummy.setIO( this.ioConsoleDummy );
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyDueOggetti);
		this.borsaDummyDueOggetti.addAttrezzo(attrezzoDummyPesoDue);
		this.borsaDummyDueOggetti.addAttrezzo(attrezzoDummyPesoUnitario);
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
		
		assertEquals(3 , this.borsaDummyDueOggetti.getPeso());

		this.comandoPrendiDummy.esegui(partitaDummy);
		
		assertEquals(0, this.stanzaDummy.getNumeroAttrezzi());
		
		assertEquals(3 , this.borsaDummyDueOggetti.getPeso());

	}

}
