package it.uniroma3.diadia.comandi;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.DiaDia;
import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.IOConsole;
import it.uniroma3.diadia.IOSimulator;
import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.fixture.Fixture;

public class ComandoVaiTest {

	private Stanza stanzaUnoDummy;
	private Stanza stanzaDueDummy;
	private Labirinto labirintoDummy;
	private Partita partitaDummy;
	private AbstractComando comandoVaiDummy;
	private IO ioConsoleDummy;
	private String direzione;

	@Before
	public void setUp() throws Exception {

		this.labirintoDummy = new Labirinto();
		this.partitaDummy = new Partita(labirintoDummy);
		this.stanzaUnoDummy = new Stanza("Stanza Uno");
		this.stanzaDueDummy = new Stanza("Stanza Due");
		this.comandoVaiDummy = new ComandoVai();
		this.ioConsoleDummy = new IOConsole();
		this.direzione  = "nord";

	}
	
	public void assertContains(String expected, String interaRiga) {
		assertTrue(interaRiga.contains(expected));
		}

	@Test
	public void testVaiDaStanzaUnoAStanzaDue() {
		this.comandoVaiDummy.setIO( this.ioConsoleDummy );
		this.comandoVaiDummy.setParametro(direzione);
		this.labirintoDummy.setStanzaIniziale(stanzaUnoDummy);
		this.partitaDummy.setStanzaCorrente(stanzaUnoDummy);
		this.stanzaUnoDummy.impostaStanzaAdiacente("nord", stanzaDueDummy);
		this.stanzaDueDummy.impostaStanzaAdiacente("sud", stanzaUnoDummy);

		assertEquals(this.stanzaUnoDummy, this.partitaDummy.getStanzaCorrente());

		this.comandoVaiDummy.esegui(partitaDummy);

		assertEquals(this.stanzaDueDummy, this.partitaDummy.getStanzaCorrente());
	}

	@Test
	public void testVaiDirezioneInesistente() {
		this.comandoVaiDummy.setIO( this.ioConsoleDummy );
		this.comandoVaiDummy.setParametro(this.direzione);
		this.labirintoDummy.setStanzaIniziale(stanzaUnoDummy);
		this.partitaDummy.setStanzaCorrente(stanzaUnoDummy);
		this.stanzaUnoDummy.impostaStanzaAdiacente("ovest", stanzaDueDummy);
		this.stanzaDueDummy.impostaStanzaAdiacente("est", stanzaUnoDummy);

		assertEquals(this.stanzaUnoDummy, this.partitaDummy.getStanzaCorrente());

		this.comandoVaiDummy.esegui(partitaDummy);

		assertEquals(this.stanzaUnoDummy, this.partitaDummy.getStanzaCorrente());
	}

	@Test
	public void testPartitaConCamandoVai() {
		Map<Integer,String> comandiDaEseguire = new HashMap<>(); 
		comandiDaEseguire.put(0, "vai sud");
		comandiDaEseguire.put(1, "fine");
		//		{"vai sud", "fine"};
		IOSimulator io = Fixture.creaSimulazionePartitaEGioca(comandiDaEseguire);
		assertTrue(io.hasNextMessaggio());
		assertEquals(DiaDia.getMessaggioBenvenuto(), io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N10", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertEquals(ComandoFine.MESSAGGIO_FINE, io.nextMessaggio());
	}
	
	@Test
	public void testPartitaConCamandoVaiPartitaLunga() {
		Map<Integer,String> comandiDaEseguire = new HashMap<>(); 
		comandiDaEseguire.put(0, "vai sud");
		comandiDaEseguire.put(1, "vai est");
		comandiDaEseguire.put(2, "vai ovest");
		comandiDaEseguire.put(3, "vai sud");
		comandiDaEseguire.put(4, "vai nord");
		comandiDaEseguire.put(5, "fine");
		//		{"vai sud","vai est","vai ovest", "vai sud", "vai nord", "fine"};
		IOSimulator io = Fixture.creaSimulazionePartitaEGioca(comandiDaEseguire);
		assertTrue(io.hasNextMessaggio());
		assertEquals(DiaDia.getMessaggioBenvenuto(), io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N10", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N11", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Atrio", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N10", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Atrio", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertEquals(ComandoFine.MESSAGGIO_FINE, io.nextMessaggio());
	}

	@Test
	public void testPartitaConCamandoVaiEStanzaBloccata() {
		Map<Integer,String> comandiDaEseguire = new HashMap<>(); 
		comandiDaEseguire.put(0, "vai sud");
		comandiDaEseguire.put(1, "vai ovest");
		comandiDaEseguire.put(2, "vai nord");
		comandiDaEseguire.put(3, "vai est");
		comandiDaEseguire.put(4, "vai nord");

		comandiDaEseguire.put(5, "fine");
		//		{"vai sud", "vai ovest", "vai nord", "vai est", "vai nord", "fine"};
		IOSimulator io = Fixture.creaSimulazionePartitaEGioca(comandiDaEseguire);
		assertTrue(io.hasNextMessaggio());
		assertEquals(DiaDia.getMessaggioBenvenuto(), io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N10", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Laboratorio Campus", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Magica", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Bloccata", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Bloccata", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertEquals(ComandoFine.MESSAGGIO_FINE, io.nextMessaggio());
	}


}
