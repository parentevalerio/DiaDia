package it.uniroma3.diadia.comandi;

import static org.junit.Assert.assertEquals;


import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.IOConsole;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Borsa;

public class ComandoPosaTest {

	private Attrezzo attrezzoDummyPesoUnitario;
	private Attrezzo attrezzoDummyPesoDue;
	
	private Stanza stanzaDummy;
	
	private AbstractComando comandoPosaDummy;
	
	private Partita partitaDummy;
	
	private IOConsole ioConsoleDummy;
	
	private Borsa borsaDummyUnOggetto;
	private Borsa borsaDummyDueOggetti;
	private Borsa borsaDummyVuota;
	
	private Labirinto labirintoDummy;
	

	
	@Before
	public void setUp() {
		
		this.attrezzoDummyPesoUnitario = new Attrezzo("attrezzoDummyPesoUnitario", 1);
		this.attrezzoDummyPesoDue = new Attrezzo("attrezzoDummyPesoDue", 2);

		this.stanzaDummy = new Stanza("stanzaDummy");
		
		this.comandoPosaDummy = new ComandoPosa();
		this.ioConsoleDummy = new IOConsole();
		
		this.borsaDummyUnOggetto = new Borsa();
		this.borsaDummyDueOggetti = new Borsa();
		this.borsaDummyVuota = new Borsa();

		this.labirintoDummy = new Labirinto();
		this.partitaDummy = new Partita(labirintoDummy);

		
		
		


	}
	
	@Test
	public void testPosaAttrezzoConBorsaVuota() {
		
		this.comandoPosaDummy.setParametro(this.attrezzoDummyPesoUnitario.getNome());
		this.comandoPosaDummy.setIO( this.ioConsoleDummy );
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyVuota);
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
		
		this.comandoPosaDummy.esegui(partitaDummy);
		assertEquals(0, this.stanzaDummy.getNumeroAttrezzi());
	}


	@Test
	public void testPosaAttrezzoConPesoUnitario() {
		
		this.comandoPosaDummy.setParametro(this.attrezzoDummyPesoUnitario.getNome());
		this.comandoPosaDummy.setIO( this.ioConsoleDummy );
		this.borsaDummyUnOggetto.addAttrezzo(attrezzoDummyPesoUnitario) ;
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyUnOggetto);
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
		
		this.comandoPosaDummy.esegui(partitaDummy);
		assertEquals(1, this.stanzaDummy.getNumeroAttrezzi());
	}
	
	
	@Test
	public void testPosaAttrezzoConPesoDue() {
		
		this.comandoPosaDummy.setParametro(this.attrezzoDummyPesoUnitario.getNome());
		this.comandoPosaDummy.setIO( this.ioConsoleDummy );
		this.borsaDummyDueOggetti.addAttrezzo(attrezzoDummyPesoUnitario);
		this.borsaDummyDueOggetti.addAttrezzo(attrezzoDummyPesoDue);
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyDueOggetti);
		
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
		

		this.comandoPosaDummy.esegui(partitaDummy);
		
		this.comandoPosaDummy.setParametro(this.attrezzoDummyPesoDue.getNome());
		this.comandoPosaDummy.esegui(partitaDummy);
		
		assertEquals(2, this.stanzaDummy.getNumeroAttrezzi());
	}
	
	@Test
	public void testPosaAttrezzoNumeroDue() {
		
		this.comandoPosaDummy.setIO( this.ioConsoleDummy );
		this.borsaDummyDueOggetti.addAttrezzo(attrezzoDummyPesoUnitario);
		this.borsaDummyDueOggetti.addAttrezzo(attrezzoDummyPesoDue);
		this.partitaDummy.getGiocatore().setBorsa(borsaDummyDueOggetti);
		
		this.labirintoDummy.setStanzaIniziale(stanzaDummy);
		this.partitaDummy.setStanzaCorrente(stanzaDummy);
				
		this.comandoPosaDummy.setParametro(this.attrezzoDummyPesoDue.getNome());
		this.comandoPosaDummy.esegui(partitaDummy);
		
		assertEquals(1, this.stanzaDummy.getNumeroAttrezzi());
	}


}
