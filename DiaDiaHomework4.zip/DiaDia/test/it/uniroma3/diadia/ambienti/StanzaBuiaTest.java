package it.uniroma3.diadia.ambienti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.DiaDia;
import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.IOConsole;
import it.uniroma3.diadia.IOSimulator;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.comandi.AbstractComando;
import it.uniroma3.diadia.comandi.ComandoFine;
import it.uniroma3.diadia.comandi.FabbricaDiComandi;
import it.uniroma3.diadia.comandi.FabbricaDiComandiRiflessiva;
import it.uniroma3.diadia.fixture.Fixture;
import it.uniroma3.diadia.giocatore.Borsa;

public class StanzaBuiaTest {

	private Attrezzo attrezzoDummyIlluminante;
	private Borsa borsaDummy;
	private Stanza stanzaBuiaConUnAttrezzoIlluminante;
	private Stanza stanzaBuiaSenzaAttrezzoIlluminante;
	private Labirinto labirintoDummy;
	private Partita partitaDummy;
	private IO ioConsoleDummy;
	private String istruzione;
	@SuppressWarnings("unused")
	private AbstractComando comandoGuardaDummy;
	private FabbricaDiComandi factory ;
	
	@Before
	public void setUp() throws FileNotFoundException {
		this.borsaDummy = new Borsa(10);
		this.attrezzoDummyIlluminante = new Attrezzo("Attrezzo Dummy Illuminante", 0);
		this.borsaDummy.addAttrezzo(attrezzoDummyIlluminante);
		
		this.labirintoDummy = Labirinto.newBuilder().getLabirinto();
		this.partitaDummy = new Partita(labirintoDummy);
		
		this.stanzaBuiaConUnAttrezzoIlluminante = new StanzaBuia("Stanza Illuminata", "Attrezzo Dummy Illuminante");
		this.stanzaBuiaSenzaAttrezzoIlluminante = new StanzaBuia("Stanza Buia");
				
		this.ioConsoleDummy = new IOConsole();
		
		this.istruzione = "guarda";
		this.comandoGuardaDummy = null;
		this.factory = new FabbricaDiComandiRiflessiva();

		

	}

	public void assertContains(String expected, String interaRiga) {
		assertTrue(interaRiga.contains(expected));
		}

	@Test
	public void testConStanzaIlluminata() {

//		this.comandoGuardaDummy.setIO(this.ioConsoleDummy);
		
		try {
			this.comandoGuardaDummy = factory.costruisciComando(istruzione, ioConsoleDummy);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		this.partitaDummy.getGiocatore().setBorsa(borsaDummy);
		this.labirintoDummy.setStanzaIniziale(stanzaBuiaConUnAttrezzoIlluminante);
		this.partitaDummy.setStanzaCorrente(stanzaBuiaConUnAttrezzoIlluminante);
		this.stanzaBuiaConUnAttrezzoIlluminante.addAttrezzo(attrezzoDummyIlluminante);
		
//		this.comandoGuardaDummy.setIO(this.ioConsoleDummy);
//		this.comandoGuardaDummy.esegui(partitaDummy);
		
		assertEquals( this.stanzaBuiaConUnAttrezzoIlluminante.getDescrizione() , this.partitaDummy.getStanzaCorrente().getDescrizione());
	}

	
	@Test
	public void testSenzaStanzaIlluminata() {

//		this.comandoGuardaDummy.setIO(this.ioConsoleDummy);
		
		try {
			this.comandoGuardaDummy = factory.costruisciComando(istruzione, ioConsoleDummy);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		this.partitaDummy.getGiocatore().setBorsa(borsaDummy);
		this.labirintoDummy.setStanzaIniziale(stanzaBuiaSenzaAttrezzoIlluminante);
		this.partitaDummy.setStanzaCorrente(stanzaBuiaSenzaAttrezzoIlluminante);
		
//		this.comandoGuardaDummy.setIO(this.ioConsoleDummy);
//		this.comandoGuardaDummy.esegui(partitaDummy);
		
		assertEquals( this.stanzaBuiaConUnAttrezzoIlluminante.getDescrizione() , this.partitaDummy.getStanzaCorrente().getDescrizione());
	}
	
	//testa insieme: comando vai, comando prendi, comando posa,,comando guarda, comando fine
	//porta un giocatore fino alla stanza buia prendendo e lasciando la lanterna 
	//al momento giusto e nel posto giusto
	@Test
	public void testPartitaConPartitaInteraESbloccoStanzaBloccata() {
		Map<Integer,String> comandiDaEseguire = new HashMap<>(); 

		comandiDaEseguire.put(0, "vai sud");
		comandiDaEseguire.put(1, "vai est");
		comandiDaEseguire.put(2, "prendi lanterna");
		comandiDaEseguire.put(3, "vai est");
		comandiDaEseguire.put(4, "vai nord");
		comandiDaEseguire.put(5, "vai ovest");
		comandiDaEseguire.put(6, "posa lanterna");
		comandiDaEseguire.put(7, "guarda");
		comandiDaEseguire.put(8, "fine");
		//		{"vai sud","vai est","prendi lanterna", "vai est", "vai nord",
		//		 "vai ovest", "posa lanterna", "guarda", "fine"};
		IOSimulator io = Fixture.creaSimulazionePartitaEGioca(comandiDaEseguire);
		assertTrue(io.hasNextMessaggio());
		assertEquals(DiaDia.getMessaggioBenvenuto(), io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N10", io.nextMessaggio());	
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N11", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("lanterna", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Laboratorio Campus", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Magica", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Qui c'� un buio pesto", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("lanterna", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Buia", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("20", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		
		assertEquals(ComandoFine.MESSAGGIO_FINE, io.nextMessaggio());
	}

	
	
}
