package it.uniroma3.diadia.ambienti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.DiaDia;
import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.IOConsole;
import it.uniroma3.diadia.IOSimulator;
import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.comandi.AbstractComando;
import it.uniroma3.diadia.comandi.ComandoFine;
import it.uniroma3.diadia.comandi.FabbricaDiComandi;
import it.uniroma3.diadia.comandi.FabbricaDiComandiRiflessiva;
import it.uniroma3.diadia.fixture.Fixture;
import it.uniroma3.diadia.giocatore.Borsa;

public class StanzaBloccataTest {

	private Attrezzo attrezzoDummySbloccante;
	private Borsa borsaDummy;
	private Stanza stanzaConUnAttrezzoBloccata;
	private Stanza stanzaLocked;
	private Labirinto labirintoDummy;
	private Partita partitaDummy;
	private IO ioConsoleDummy;
	private String direzione;
	private String istruzione;
	private AbstractComando comandoVaiDummy;
	private FabbricaDiComandi factory ;
	
	@Before
	public void setUp() throws FileNotFoundException {
		this.borsaDummy = new Borsa(10);
		this.attrezzoDummySbloccante = new Attrezzo("Attrezzo Dummy Sbloccante", 0);
		this.borsaDummy.addAttrezzo(attrezzoDummySbloccante) ;
		this.labirintoDummy = Labirinto.newBuilder().getLabirinto();
		this.partitaDummy = new Partita(labirintoDummy);
		this.stanzaConUnAttrezzoBloccata = new StanzaBloccata("Stanza Con Un Attrezzo Bloccata","Attrezzo Dummy Sbloccante", Direzione.NORD);
		this.stanzaLocked = new Stanza("Stanza Locked");
		this.ioConsoleDummy = new IOConsole();
		this.direzione  = "nord";
		
		this.istruzione = "vai nord";
		this.comandoVaiDummy = null;
		this.factory = new FabbricaDiComandiRiflessiva();
	}
	
	public void assertContains(String expected, String interaRiga) {
		assertTrue(interaRiga.contains(expected));
		}


	@Test
	public void testStanzaCheSiSblocca() {
		try {
			this.comandoVaiDummy = factory.costruisciComando(istruzione, ioConsoleDummy);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.comandoVaiDummy.setIO( this.ioConsoleDummy );
		this.comandoVaiDummy.setParametro(direzione);
		this.partitaDummy.getGiocatore().setBorsa(borsaDummy);
		this.labirintoDummy.setStanzaIniziale(stanzaConUnAttrezzoBloccata);
		this.partitaDummy.setStanzaCorrente(stanzaConUnAttrezzoBloccata);
		this.stanzaConUnAttrezzoBloccata.impostaStanzaAdiacente("nord", stanzaLocked);
		this.stanzaLocked.impostaStanzaAdiacente("sud", stanzaConUnAttrezzoBloccata);
		this.partitaDummy.getStanzaCorrente().addAttrezzo(attrezzoDummySbloccante);
		
		this.comandoVaiDummy.esegui(partitaDummy);
		assertEquals("Stanza Locked", this.partitaDummy.getStanzaCorrente().getNome());
	}
	
	@Test
	public void testStanzaCheNonSiSblocca() {
		try {
			this.comandoVaiDummy = factory.costruisciComando(istruzione, ioConsoleDummy);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.comandoVaiDummy.setIO( this.ioConsoleDummy );
		this.comandoVaiDummy.setParametro(direzione);
		this.partitaDummy.getGiocatore().setBorsa(borsaDummy);
		
		this.labirintoDummy.setStanzaIniziale(stanzaConUnAttrezzoBloccata);
		this.partitaDummy.setStanzaCorrente(stanzaConUnAttrezzoBloccata);
		
		this.stanzaConUnAttrezzoBloccata.impostaStanzaAdiacente("nord", stanzaLocked);
		this.stanzaLocked.impostaStanzaAdiacente("sud", stanzaConUnAttrezzoBloccata);
		
		this.comandoVaiDummy.esegui(partitaDummy);
		assertEquals("Stanza Con Un Attrezzo Bloccata", this.partitaDummy.getStanzaCorrente().getNome());
	}
	
	//testa insieme: comando vai, comando prendi, comando posa, comando fine
	//porta un giocatore fino alla stanza locked prendendo e lasciando la chiave 
	//al momento giusto e nel posto giusto
	//Con questi tipi di test viene implicitamente testato anche LabirintoBuilder
	@Test
	public void testPartitaConPartitaInteraESbloccoStanzaBloccata() {
		Map<Integer,String> comandiDaEseguire = new HashMap<>(); 

		comandiDaEseguire.put(0, "prendi chiave");
		comandiDaEseguire.put(1, "vai sud");
		comandiDaEseguire.put(2, "vai ovest");
		comandiDaEseguire.put(3, "vai nord");
		comandiDaEseguire.put(4, "vai est");
		comandiDaEseguire.put(5, "posa chiave");
		comandiDaEseguire.put(6, "vai nord");

		comandiDaEseguire.put(7, "fine");
		//		{"prendi chiave", "vai sud", "vai ovest", "vai nord", "vai est",
		//		 "posa chiave", "vai nord", "fine"};
		IOSimulator io = Fixture.creaSimulazionePartitaEGioca(comandiDaEseguire);
		assertTrue(io.hasNextMessaggio());
		assertEquals(DiaDia.getMessaggioBenvenuto(), io.nextMessaggio());
		assertContains("chiave", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N10", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Laboratorio Campus", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Magica", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Bloccata", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("chiave", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Locked", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertEquals(ComandoFine.MESSAGGIO_FINE, io.nextMessaggio());
	}


	


}
