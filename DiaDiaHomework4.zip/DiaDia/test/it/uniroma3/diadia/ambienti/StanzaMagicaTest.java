package it.uniroma3.diadia.ambienti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.DiaDia;
import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.IOConsole;
import it.uniroma3.diadia.IOSimulator;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.comandi.AbstractComando;
import it.uniroma3.diadia.comandi.ComandoFine;
import it.uniroma3.diadia.comandi.FabbricaDiComandi;
import it.uniroma3.diadia.comandi.FabbricaDiComandiRiflessiva;
import it.uniroma3.diadia.fixture.Fixture;
import it.uniroma3.diadia.giocatore.Borsa;

public class StanzaMagicaTest {
	private Attrezzo magic;
	private Attrezzo attrezzoRiempitivo1;
	private Attrezzo attrezzoRiempitivo2;
	private Attrezzo attrezzoRiempitivo3;
	private Borsa borsaDummy;
	private Stanza stanzaMagica;
	private Labirinto labirintoDummy;
	private Partita partitaDummy;
	private IO ioConsoleDummy;
	private String istruzioneGuarda;
	private String istruzionePosa;
	private AbstractComando comandoGuardaDummy;
	private AbstractComando comandoPosaDummy;
	private FabbricaDiComandi factory ;


	@Before
	public void setUp() throws FileNotFoundException {
		this.borsaDummy = new Borsa();
		this.magic = new Attrezzo("magic", 1);
		this.attrezzoRiempitivo1 = new Attrezzo("Attrezzo Riempitivo1", 0);
		this.attrezzoRiempitivo2 = new Attrezzo("Attrezzo Riempitivo2", 0);
		this.attrezzoRiempitivo3 = new Attrezzo("Attrezzo Riempitivo3", 0);

		this.borsaDummy.addAttrezzo(attrezzoRiempitivo1);
		this.borsaDummy.addAttrezzo(attrezzoRiempitivo2);
		this.borsaDummy.addAttrezzo(attrezzoRiempitivo3);
		this.borsaDummy.addAttrezzo(magic);

		this.labirintoDummy = Labirinto.newBuilder().getLabirinto();
		this.partitaDummy = new Partita(labirintoDummy);

		this.stanzaMagica = new StanzaMagica("Stanza Magica");

		this.comandoGuardaDummy = null;
		this.comandoPosaDummy = null;
		this.istruzioneGuarda = "guarda";
		this.istruzionePosa = "posa magic";
		this.factory = new FabbricaDiComandiRiflessiva();

		this.ioConsoleDummy = new IOConsole();
 

	}

	public void assertContains(String expected, String interaRiga) {
		assertTrue(interaRiga.contains(expected));
	}

//	@Test
//	public void testConStanzaMagica() {
//	
//		this.borsaDummy.addAttrezzo(magic);
//		this.partitaDummy.getGiocatore().setBorsa(borsaDummy);
//		this.labirintoDummy.setStanzaIniziale(stanzaMagica);
//		this.partitaDummy.setStanzaCorrente(stanzaMagica);
//		this.stanzaMagica.addAttrezzo(attrezzoRiempitivo1);
//		this.stanzaMagica.addAttrezzo(attrezzoRiempitivo2);
//		this.stanzaMagica.addAttrezzo(attrezzoRiempitivo3);
//		
//
//
//		try {
//			this.comandoGuardaDummy = factory.costruisciComando(istruzioneGuarda, ioConsoleDummy);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		assertContains( "Stanza Magica" , this.partitaDummy.getStanzaCorrente().getDescrizione());
//	
//	
//		try {
//			this.comandoPosaDummy = factory.costruisciComando(istruzionePosa, ioConsoleDummy);
//		} catch (Exception ex) {
//			// TODO Auto-generated catch block
//			ex.printStackTrace();		
//		}
//		this.comandoPosaDummy.setIO( this.ioConsoleDummy );
//		this.comandoPosaDummy.setParametro(magic.getNome());
//			assertContains( "cigam", this.partitaDummy.getStanzaCorrente().getDescrizione());
//
//
//	}


	//testa insieme: comando vai, comando prendi, comando posa,,comando guarda, comando fine
	//porta un giocatore fino alla stanza buia prendendo e lasciando la lanterna 
	//al momento giusto e nel posto giusto
	@Test
	public void testPartitaConPartitaInteraEMagiaSuStanzaMagica() {
		Map<Integer,String> comandiDaEseguire = new HashMap<>(); 

		comandiDaEseguire.put(0, "prendi chiave");
		comandiDaEseguire.put(1, "vai sud");
		comandiDaEseguire.put(2, "prendi kiwi");
		comandiDaEseguire.put(3, "prendi piuma");
		comandiDaEseguire.put(4, "vai est");
		comandiDaEseguire.put(5, "prendi lanterna");
		comandiDaEseguire.put(6, "vai est");
		comandiDaEseguire.put(7, "vai nord");
		comandiDaEseguire.put(8, "posa chiave");
		comandiDaEseguire.put(9, "posa piuma");
		comandiDaEseguire.put(10, "posa lanterna");
		comandiDaEseguire.put(11, "posa kiwi");
		comandiDaEseguire.put(12, "guarda");
		comandiDaEseguire.put(13, "fine");
		//		{"prendi chiave", "vai sud", "prendi kiwi", "prendi piuma", "vai est",
		//       "prendi lanterna", "vai est", "vai nord",
		//		 "posa chiave", "posa piuma", "posa lanterna",
		//		 "posa kiwi", "guarda",
		//		 "fine"};
		IOSimulator io = Fixture.creaSimulazionePartitaEGioca(comandiDaEseguire);
		assertTrue(io.hasNextMessaggio());
		assertEquals(DiaDia.getMessaggioBenvenuto(), io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("chiave", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Aula N10", io.nextMessaggio());	
		assertTrue(io.hasNextMessaggio());
		assertContains("kiwi", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("piuma", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("N11", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("lanterna", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Laboratorio Campus", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("Stanza Magica", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("chiave", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("piuma", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("lanterna", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("kiwi", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("iwik", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());
		assertContains("20", io.nextMessaggio());
		assertTrue(io.hasNextMessaggio());

		assertEquals(ComandoFine.MESSAGGIO_FINE, io.nextMessaggio());
	}
}
