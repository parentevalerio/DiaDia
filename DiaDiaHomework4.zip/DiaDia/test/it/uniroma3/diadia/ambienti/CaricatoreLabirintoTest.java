package it.uniroma3.diadia.ambienti;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.StringReader;

import org.junit.Test;

public class CaricatoreLabirintoTest {

	private static final String DESCRIZIONE_LABIRINTO
		= "Stanze:\n"
		+"N10\n"
		+"N11\n"
		+"Biblioteca\n"
		+"StanzaLocked\n"
		+"Magiche:\n"
		+"N1\n"
		+"Bloccate:\n"
		+"StanzaBloccata chiave nord\n"
		+"Buie:\n"
		+"StanzaBuia\n"
		+"Iniziale:\n"
		+"N10\n"
		+"Vincente:\n"
		+"Biblioteca\n"
		+"Attrezzi:\n"
		+"Osso 5 N10\n"
		+"Maghi:\n"
		+"MagoTorta Cakez torta 3 StanzaLocked\n"
		+"Streghe:\n"
		+"Strega BAKA! N11\n"
		+"Cani:\n"
		+"Doggo GRR chiave 0 osso StanzaBuia\n"
		+"Uscite:\n"
		+"N10 nord Biblioteca\n"
		+"Biblioteca sud N10 \n";
		
		
	@Test
	public void testCarica() throws FileNotFoundException {
		CaricatoreLabirinto caricatore = new CaricatoreLabirinto(new StringReader(DESCRIZIONE_LABIRINTO));
		caricatore.carica();
		Labirinto labirinto = caricatore.getLabirinto();
		assertEquals("N10", labirinto.getStanzaIniziale().getNome());
		assertEquals("Biblioteca", labirinto.getStanzaVincente().getNome());
		assertEquals("Osso", labirinto.getStanzaIniziale().getAttrezzo("Osso").getNome());
		assertEquals(5, labirinto.getStanzaIniziale().getAttrezzo("Osso").getPeso());
	}

}
