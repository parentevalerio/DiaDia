package it.uniroma3.diadia.ambienti;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.attrezzi.Attrezzo;


public class StanzaTest {
	
	private Attrezzo attrezzoDummy;
	private Stanza stanzaConUnAttrezzo;
	private Stanza stanzaVuota;
	
	@Before
	public void setUp() {
		this.attrezzoDummy = new Attrezzo ("attrezzoDummy", 0);
		this.stanzaVuota = new Stanza ("Stanza vuota");
		this.stanzaConUnAttrezzo = new Stanza ("Stanza con un attrezzo");
		this.stanzaConUnAttrezzo.addAttrezzo(attrezzoDummy);
	}

	@Test
	public void testGetAttrezzoPresente() {
		assertSame(attrezzoDummy, this.stanzaConUnAttrezzo.getAttrezzo("attrezzoDummy"));
	}
	
	@Test
	public void testGetAttrezzoNonPresente() {
		assertSame(null, this.stanzaVuota.getAttrezzo("attrezzoDummy"));
	}

	
	@Test
	public void testAddAttrezzo() {
		assertTrue (this.stanzaVuota.addAttrezzo(attrezzoDummy));
	}
	
	@Test (expected = java.lang.NullPointerException.class)
	public void testAddAttrezzoNull() {
		stanzaVuota.addAttrezzo(null);
	}
	
	@Test
	public void testRemoveAttrezzo() {
		assertTrue ( this.stanzaConUnAttrezzo.removeAttrezzo("attrezzoDummy"));
	}
	
//	@Test (expected = java.lang.AssertionError.class)
//	public void testRemoveAttrezzoNull() {
//		stanzaConUnAttrezzo.removeAttrezzo(null);
//	}
	
}























