package it.uniroma3.diadia.fixture;

import java.util.Map;

import it.uniroma3.diadia.DiaDia;
import it.uniroma3.diadia.IOSimulator;
import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Labirinto.LabirintoBuilder;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class Fixture {

	public static IOSimulator creaSimulazionePartitaEGioca(Map<Integer,String> righeDaLeggere) {
		Labirinto labirinto = new Labirinto();
		labirinto = Fixture.diaDia(labirinto);
		IOSimulator io = new IOSimulator (righeDaLeggere);
		new DiaDia(io,labirinto).gioca(io);
		return io;
	}

	public static IOSimulator creaSimulazionePartitaEGiocaMonolocale(Map<Integer,String> righeDaLeggere) {
		Labirinto labirinto = new Labirinto();
		labirinto = Fixture.monolocale(labirinto);
		IOSimulator io = new IOSimulator (righeDaLeggere);
		new DiaDia(io,labirinto).gioca(io);
		return io;
	}

	public static Attrezzo creaAttrezzoEAggiungiAStanza(Stanza stanzaDaRiempire, String nomeAttrezzo, int peso) {
		Attrezzo attrezzo = new Attrezzo(nomeAttrezzo, peso);
		stanzaDaRiempire.addAttrezzo(attrezzo);
		return attrezzo;
	}
	public static Labirinto diaDia(Labirinto labirinto) {

		Labirinto labirintoDiDiaDia = Labirinto.newBuilder()
				.addStanzaVincente("Biblioteca")
				.addStanzaIniziale("Atrio")
				.addAttrezzo("Atrio","chiave", 0)
				.addStanza("Aula N11")
				.addAttrezzo("Aula N11","lanterna", 3)
				.addStanza("Aula N10")
				.addAttrezzo("Aula N10","kiwi", 1)
				.addAttrezzo("Aula N10","piuma", 0)
				.addAttrezzo("Aula N10","piombo", 10)
				.addStanza("Laboratorio Campus")
				.addAttrezzo("Laboratorio Campus","ps", 5)
				.addStanza("Biblioteca")
				.addStanzaMagica("Stanza Magica")
				.addStanzaBuia("Stanza Buia")
				.addStanzaBloccata("Stanza Bloccata", "chiave","nord")
				.addStanza("Stanza Locked")

				.addAdiacenza("Atrio","Biblioteca" , "nord")
				.addAdiacenza("Atrio", "Aula N11" , "est" )
				.addAdiacenza("Atrio", "Aula N10" , "sud" )
				.addAdiacenza("Atrio", "Laboratorio Campus" , "ovest" )

				.addAdiacenza("Aula N11", "Atrio" , "ovest" )
				.addAdiacenza("Aula N11", "Laboratorio Campus" , "est" )

				.addAdiacenza("Aula N10", "Atrio" , "nord" )
				.addAdiacenza("Aula N10", "Aula N11" , "est" )
				.addAdiacenza("Aula N10", "Laboratorio Campus" , "ovest")

				.addAdiacenza("Laboratorio Campus", "Atrio" , "est" )
				.addAdiacenza("Laboratorio Campus", "Aula N11" ,"ovest" )
				.addAdiacenza("Laboratorio Campus", "Stanza Magica" , "nord" )

				.addAdiacenza("Stanza Magica", "Laboratorio Campus" ,"sud" )
				.addAdiacenza("Stanza Magica", "Stanza Buia" ,"ovest" )
				.addAdiacenza("Stanza Magica", "Stanza Bloccata" ,"est" )

				.addAdiacenza("Stanza Buia", "Stanza Magica" ,"est" )

				.addAdiacenza("Stanza Bloccata", "Stanza Magica" ,"ovest" )
				.addAdiacenza("Stanza Bloccata", "Stanza Locked" ,"nord" )

				.addAdiacenza("Stanza Locked", "Stanza Bloccata" ,"sud" )

				.addAdiacenza("Biblioteca", "Atrio" ,"sud" )
				.getLabirinto();

		return labirintoDiDiaDia;
	}

	public static Labirinto monolocale(Labirinto labirinto) {

		Labirinto monolocale = new LabirintoBuilder()
				.addStanzaIniziale("salotto") 
				.addStanzaVincente("salotto") 
				.getLabirinto();
		return monolocale;
	}

	public static Labirinto bilocale(Labirinto labirinto) {
		
		Labirinto bilocale = new LabirintoBuilder()
				.addStanzaIniziale("salotto")
				.addStanzaVincente("camera")
				.addAttrezzo("camera","letto",10)
				.addAdiacenza("salotto", "camera", "nord") 
				.getLabirinto();
		return bilocale;
	}

}
